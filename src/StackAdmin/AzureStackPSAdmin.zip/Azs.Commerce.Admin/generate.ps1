
$rpName = "commerce"
$location = pwd
$moduleName = "CommerceAdmin"

. ..\..\..\tools\generate.ps1 -RPName $rpName -Location $location -Name $moduleName -Admin